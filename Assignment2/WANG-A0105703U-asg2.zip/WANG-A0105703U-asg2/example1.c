int main() {
    int a,b,c,d = 0;
    if (a > 0)
        c = 5;
    else
        c = 10;
    if (b > 0)
        d = -11;

}