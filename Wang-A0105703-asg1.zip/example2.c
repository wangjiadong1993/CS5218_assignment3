//Author: Wang Jiadong
//Matric Number: A0105703
//Email: E0267418@u.nus.edu

#include <stdio.h>
int main(){
  int b,c,sink, source, N;
  int i = 0;
  while(i < N){
    if (i % 2 == 0){
      b = source;
    }else{
      c = b;
    }
    i ++;
  }
  sink = c;
}
